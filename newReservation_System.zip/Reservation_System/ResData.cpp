#include "ResData.h"

ResData::ResData() {

}

vector<Seat>  ResData::readFileSeat(string nameFile) {
    int index;
    bool take;
    string namePassenger;
    ifstream myfile(nameFile);
    vector<Seat> seats;
    Bus bus;
    for(int i = 0; i < bus.getSeatNum(); ++i) {
        Seat seat = Seat(i);
        seats.push_back(seat);
        if(myfile >> index >> take >> namePassenger) {
            seats[i].setIndex(index);
            seats[i].setTake(take);
            seats[i].setNamePassenger(namePassenger);
        }
    }
    return seats;
}


int ResData::getSizeDataPassenger(string nameFile){
    ifstream myfile(nameFile);
    int count = 0;
    string aLineStr;
    while(getline(myfile, aLineStr)) { 
        count++;
    }
    return count;
}

vector<Ticket> ResData::readFilePassenger(string nameFile, int size) {
    string name, departure, destination, date, time;
    int ticketNum;
    ifstream myfile(nameFile);
    vector<Ticket> tickets;
    for(int i = 0; i < size; ++i) {
        Ticket ticket = Ticket(i);
        tickets.push_back(ticket);
        if (myfile >> name >> departure >> destination >> date >> time >> ticketNum) {
            tickets[i].setNameOfPassenger(name);
            tickets[i].setDepartureCity(departure);
            tickets[i].setDestinationCity(destination);
            tickets[i].setDate(date);
            tickets[i].setTime(time);
            tickets[i].setTicketNum(ticketNum);
        }
    }
    return tickets;
}

void ResData::writeFilePassenger(string nameFile, vector<Ticket> tickets, ios_base::openmode mode) {

    fstream revervationData; 
    revervationData.open(nameFile, mode);
    if (!revervationData) {}
    else { 
        for (int i = 0; i < tickets.size(); ++i) {
            revervationData << tickets[i].getNameOfPassenger();
            revervationData << " " << tickets[i].getDepartureCity();       
            revervationData << " " << tickets[i].getDestinationCity();
            revervationData << " " << tickets[i].getDate();
            revervationData << " " << tickets[i].getTime();
            revervationData << " " << tickets[i].getTicketNum() << endl;
        }
        revervationData.close();                   
    }

}

void ResData::writeFileSeat(string nameFile, vector<Seat> seats, ios_base::openmode mode) {

    fstream seatData; 
    seatData.open(nameFile, mode);
    Bus bus;
    if (!seatData) {}
    else {  
        for (int i = 0; i < bus.getSeatNum(); ++i) {
            seatData << seats.at(i).getIndex() << " " << seats.at(i).getTake() << " " << seats.at(i).getNamePassenger() << endl;
        }
        seatData.close();                   
    }
}