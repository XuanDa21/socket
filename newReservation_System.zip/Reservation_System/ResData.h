#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Ticket.h"
#include "Bus.h"
#include "Seat.h"

using namespace std;

class ResData{
    
    private:
    
    public:

        ResData();

        vector<Seat> readFileSeat(string);

        vector<Ticket> readFilePassenger(string, int);

        int getSizeDataPassenger(string);
      
        void writeFilePassenger(string, vector<Ticket>, ios_base::openmode);

        void writeFileSeat(string, vector<Seat>, ios_base::openmode);

};