#include <iostream>
#include "User.h"

User::User(){

}

void User::setInForPassenger() {
    string name, destination, departure, date, time;
    int ticketNum;
    cout << "Name of passenger: ";
    cin >> name;
    ticket.setNameOfPassenger(name);
    cout << "Departure City:";
    cin >> departure;
    ticket.setDepartureCity(departure);
    cout << "Destination City: ";
    cin >> destination;
    ticket.setDestinationCity(destination);
    cout << "Date of travel: ";
    cin >> date;
    ticket.setDate(date);
    cout << "Time of travel: ";
    cin >> time;
    ticket.setTime(time);
    cout << "Number of tickects: ";
    cin >> ticketNum;
    ticket.setTicketNum(ticketNum);
}

string User::getNameToModify(){
    ResData resData;
    vector<Ticket> ticketData;
    int sizeData = resData.getSizeDataPassenger("reservationData.txt");
    int count = 0;
    ticketData = resData.readFilePassenger("reservationData.txt", sizeData);
    string nameToModify, temNameToModify = ""; 
    cout << "Enter name wanna to modify: ";
    cin >> nameToModify;
    for(int i = 0; i < ticketData.size(); ++i) {
        int x = ticketData[i].getNameOfPassenger().compare(nameToModify);
        if(x != 0) {
            count++;
        }
    }
    if(count == ticketData.size()) {
        cout << "We doesn't have the same name passenger" << endl;
    }
    else {
        temNameToModify.assign(nameToModify);
    }
    return temNameToModify;
}


void User::printInforPassenger(Ticket ticket) {
    cout<< "Name of passenger: " << ticket.getNameOfPassenger() << endl;
    cout<< "Departure city: " << ticket.getDepartureCity() << endl;
    cout<< "Destination city: " << ticket.getDestinationCity() << endl;
    cout<< "Date: " << ticket.getDate() << endl;
    cout<< "Time: " << ticket.getTime() << endl;
    cout<< "Number of tickets: " << ticket.getTicketNum() << endl;
    cout<< "Seat of passenger: "; 
    for (int i = 0; i < ticket.getPositionSeat().size(); ++i){
        cout << ticket.getPositionSeat().at(i) << ", ";
    }
    cout << endl;
}

string User::getNameToCancel() {
    string name;
    cout << "Enter your name: ";
    cin >> name;
    return  name;
}

vector<int> User::getSeatPassenger(vector<Ticket> tickets) {
    int positionSeat, count = 0;
    vector<int> positionSeats;
    ResData resData;
    Bus bus;
    vector<Seat> seatsRead;
    seatsRead = resData.readFileSeat("seatData.txt");
    for (int i = 0; i < seatsRead.size(); ++i ) {
        if(seatsRead[i].getTake()){
            count++;
        }
    }

    if (tickets.data() -> getTicketNum() > (bus.getSeatNum() - count)) {
        cout << "We doesn't have enough seat now!!!" << endl;
         for (int i = 0; i <= count; ++i) {
            if(seatsRead[i].getTake()) {
                positionSeats.push_back(i);
            }
        }
    }

    else {
        for (int i = 0; i < tickets.data() -> getTicketNum(); ++i) {
            cout << "Seat position want to sit:";
            cin >> positionSeat;
            positionSeats.push_back(positionSeat);
        }
    }
    return positionSeats;
}

vector<string> User::getInforToSearch() {
    vector<string> inforToSearch;
    string name, date;
    char choice;
    int ch = 0;
    cout << "Please select an option from the menu below" << endl;
    cout << "n - search by name" << endl;
    cout << "d - search by date" << endl;
    cout << "-> ";
    cin >> choice;
    switch (choice) {
        case 'n':
            cout << "Enter name wanna search: ";
            cin >> name;
            inforToSearch.push_back(name);
            break;
        case 'd': 
            cout << "Enter date wanna search: ";
            cin >> date;
            inforToSearch.push_back(date);
            break;
        default:
            cout << "Please choose an option in the menu" << endl;
            break;
    }
    return inforToSearch;
}

vector<Ticket> User::getInforPassenger() {
    vector<Ticket> tickets;
    tickets.push_back(ticket);
    return tickets;
}


