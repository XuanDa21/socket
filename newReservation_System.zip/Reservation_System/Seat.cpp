#include "Seat.h"
Seat::Seat(){
    
}

Seat::Seat(int index){
    setIndex(index);
    setTake(false);
    setNamePassenger("None");
}

void Seat::setNamePassenger(string namePassenger){
    this -> namePassenger = namePassenger;
}

void Seat::setTake(bool take){
    this -> take = take;
}

int Seat::getIndex(){
    return this -> index;
}

string Seat::getNamePassenger(){
    return this -> namePassenger;
}

bool Seat::getTake(){
    return this -> take;
}

void Seat::setIndex(int index){
    this -> index = index;
}