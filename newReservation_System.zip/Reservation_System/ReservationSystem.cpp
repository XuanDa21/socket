#include "ReservationSystem.h"
ReservationSystem::ReservationSystem() {
    
}

void ReservationSystem::makeReservation() {

    User user; 
    ResData resData;
    vector<Seat> seatData;
    vector<int> positionSeat;
    seatData = resData.readFileSeat("seatData.txt");
    user.setInForPassenger();
    int count = 0;
    for(int i = 0; i < seatData.size(); ++i) {
        if(seatData[i].getTake()) {
            count++;
        }
    }   
    if( (seatData.size() - count) < user.getInforPassenger().data() -> getTicketNum()) {}
    else {
        positionSeat = user.getSeatPassenger(user.getInforPassenger());
        resData.writeFilePassenger("reservationData.txt", user.getInforPassenger(), ios::app);
    }

    for (auto i = positionSeat.begin(); i != positionSeat.end(); ++i) {
        seatData[*i].setTake(true); 
        seatData[*i].setNamePassenger(user.getInforPassenger()[0].getNameOfPassenger());
    }
    resData.writeFileSeat("seatData.txt", seatData, ios::out);   
         
}

void ReservationSystem::searchReservation() {
    ResData resData;
    User user;
    vector<string> inforToSearch;
    vector<Seat> seatsData;
    vector<Ticket> ticketsData;
    vector<int> positionSeats, positionSeatsDate;
    vector<string> namePassenger;
    int x, y, z, a, b;
    int sizeResData = resData.getSizeDataPassenger("reservationData.txt");
    seatsData = resData.readFileSeat("seatData.txt");
    ticketsData = resData.readFilePassenger("reservationData.txt", sizeResData);
    inforToSearch = user.getInforToSearch();

    for (int i = 0; i < seatsData.size(); ++i) {
        z = inforToSearch[0].compare(seatsData[i].getNamePassenger());
        if(z == 0) {
            positionSeats.push_back(seatsData[i].getIndex());
        }
    }


    for (int i = 0; i < sizeResData; ++i) {
        a = inforToSearch[0].compare(ticketsData[i].getDate());
        if(a == 0) {
            namePassenger.push_back(ticketsData[i].getNameOfPassenger());
        }
    }

    for (int i = 0; i < namePassenger.size(); ++i) {
        for (int j = 0; j < seatsData.size(); ++j) {
            b = namePassenger[i].compare(seatsData[j].getNamePassenger());
            if(b == 0) {
                positionSeatsDate.push_back(seatsData[j].getIndex());
            }
        }
    }

    for(int i = 0; i < sizeResData; ++i) {
        y = inforToSearch[0].compare(ticketsData[i].getDate());
        if(y == 0) {
            ticketsData[i].setPositionSeat(positionSeatsDate);
            user.printInforPassenger(ticketsData[i]);
        }
    }

    for(int i = 0; i < sizeResData; ++i) {
        x = inforToSearch[0].compare(ticketsData[i].getNameOfPassenger());
        if(x == 0) {
            ticketsData[i].setPositionSeat(positionSeats);
            user.printInforPassenger(ticketsData[i]);
        }
    }

}
void ReservationSystem::modifiReservation() {
    User user;
    ResData resData;
    string nameToModify;
    int sizeData = resData.getSizeDataPassenger("reservationData.txt");
    vector<int> positionSeats;
    vector<Ticket> ticketData = resData.readFilePassenger("reservationData.txt", sizeData), tickets;
    vector<Seat> seatData = resData.readFileSeat("seatData.txt");
    nameToModify = user.getNameToModify();
    int x = nameToModify.compare("");
    if(x == 0) {}
    else {
        user.setInForPassenger();
    };
    tickets = user.getInforPassenger();
    positionSeats = user.getSeatPassenger(tickets);
    for(int i = 0; i < ticketData.size(); ++i) {
        int x = nameToModify.compare(ticketData[i].getNameOfPassenger());
        if(x == 0) {
            ticketData[i].setNameOfPassenger(tickets[0].getNameOfPassenger());
            ticketData[i].setDepartureCity(tickets[0].getDepartureCity());
            ticketData[i].setDestinationCity(tickets[0].getDestinationCity());
            ticketData[i].setDate(tickets[0].getDate());
            ticketData[i].setTime(tickets[0].getTime());
            ticketData[i].setTicketNum(tickets[0].getTicketNum());
        }
    }
    for(int i = 0; i < seatData.size(); ++i) {
        int x = nameToModify.compare(seatData[i].getNamePassenger());
        if(x == 0) {
            seatData[i].setNamePassenger("None");
            seatData[i].setTake(false);
        }
    }

    for(int i = 0; i < positionSeats.size(); ++i) {
        seatData[positionSeats[i]].setTake(true);
        seatData[positionSeats[i]].setNamePassenger(tickets[0].getNameOfPassenger());
    }

    resData.writeFileSeat("seatData.txt", seatData, ios::out);
    resData.writeFilePassenger("reservationData.txt", ticketData, ios::out);
}

void ReservationSystem::cancelReservation() { 

    ResData resData;
    User user;
    Ticket ticket;
    vector<Ticket> ticketsData;
    string nameToCancel;
    int sizeDataPassenger;
    vector<Seat> seatsData;
    nameToCancel = user.getNameToCancel();
    sizeDataPassenger = resData.getSizeDataPassenger("reservationData.txt");
    ticketsData = resData.readFilePassenger("reservationData.txt", sizeDataPassenger);
    seatsData = resData.readFileSeat("seatData.txt");

    for (int i = 0; i < ticketsData.size(); ++i) {
        int x = ticketsData[i].getNameOfPassenger().compare(nameToCancel);
        if(x == 0) {
            ticketsData.erase(ticketsData.begin() + i);
        }
    }

    for (int i = 0; i < seatsData.size(); ++i) {
        int x = seatsData[i].getNamePassenger().compare(nameToCancel);
        if(x == 0) {
            seatsData[i].setTake(false);
            seatsData[i].setNamePassenger("None");
        }
    }
    resData.writeFilePassenger("reservationData.txt", ticketsData, ios::out);
    resData.writeFileSeat("seatData.txt", seatsData, ios::out);

}

void ReservationSystem::exitReservation() {
    exit(0);
}
