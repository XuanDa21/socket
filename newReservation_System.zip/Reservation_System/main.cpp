#include <iostream>
#include "Bus.h"
#include "ReservationSystem.h"

void reservationSystem();

int main() {
    reservationSystem();
    return 0;
}

void reservationSystem() {
    while(true){
        cout << "Please select an option from the menu below:" << endl;
        cout << "n -> Make Reservation" << endl;
        cout << "m -> Modify reservation" << endl;
        cout << "c -> Cancel reservation" << endl;
        cout << "s -> Search reservation" << endl;
        cout << "e -> Exit" << endl;
        char menuInput;
        cout << "-> ";
        cin >> menuInput;
        ReservationSystem reservationSystem;
        switch(menuInput){
            case 'n':
                reservationSystem.makeReservation();
                break;
            case 'm': 
                reservationSystem.modifiReservation();
                break;
            case 'c': 
                reservationSystem.cancelReservation();
                break;
            case 's': 
                reservationSystem.searchReservation();
                break;
            case 'e': 
                reservationSystem.exitReservation();
                break;
            default: 
                cout << "You have to choose an option in the menu!!!" << endl;
        }

    }

}
