#include <iostream>
#include "InforPassenger.h"
using namespace std; 

InforPassenger::InforPassenger(){

}

void InforPassenger::getInforPassenger(){

    string name, destination, departure, date, time;
    int ticketNum;
    Ticket ticket;
    cout << "Name of passenger:";
    cin >> name;
    cout << "Departure City:";
    cin >> departure;
    cout << "Destination City:";
    cin >> destination;
    cout << "Date of travel:";
    cin >> date;
    cout << "Time of travel:";
    cin >> time;
    cout << "Number of tickects:";
    cin >> ticketNum;

    ticket.setNameOfPassenger(name);
    ticket.setDepartureCity(departure);
    ticket.setDestinationCity(destination);
    ticket.setDate(date);
    ticket.setTime(time);
    ticket.setTicketNum(ticketNum);

    struct Person
    {
        char name[50];
        int age;
        float salary;
    };

    ResData resData;
    resData.writeFilePassenger("revervationData.txt", Person);
    resData.readFile("revervationData.txt");

}

