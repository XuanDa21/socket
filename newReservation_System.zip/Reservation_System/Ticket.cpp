#include "Ticket.h"

Ticket::Ticket(){

}

Ticket::Ticket(int index){
    setNameOfPassenger("");
    setDepartureCity("");
    setDestinationCity("");
    setDate("");
    setTime("");
    setTicketNum(0);
}

string Ticket::getNameOfPassenger(){
    return this -> nameOfPassenger;
}

string Ticket::getDepartureCity(){
    return this -> departureCity;
}

string Ticket::getDestinationCity(){
    return this -> destinationCity;
}

string Ticket::getDate(){
    return this -> date;
}

string Ticket::getTime(){
    return this -> time;
}

int Ticket::getTicketNum(){
    return this -> ticketNum;
}

vector<int> Ticket::getPositionSeat(){
    return this -> positionSeat;
}

void Ticket::setNameOfPassenger(string nameOfPassenger){
    this -> nameOfPassenger = nameOfPassenger;
}

void Ticket::setDepartureCity(string departureCity){
    this -> departureCity = departureCity;
}

void Ticket::setDestinationCity(string destinationCity){
    this -> destinationCity = destinationCity;
}

void Ticket::setDate(string date){
    this -> date = date;
}

void Ticket::setTime(string time){
    this -> time = time;
}

void Ticket::setTicketNum(int ticketNum){
    this -> ticketNum = ticketNum;
}

void Ticket::setPositionSeat(vector<int> positionSeat){
    this -> positionSeat = positionSeat;
}

