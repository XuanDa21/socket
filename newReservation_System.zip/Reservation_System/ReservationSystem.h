#include "User.h"
#include "Ticket.h"
#include <vector>
#include <fstream>
#include <cstring>
using namespace std;

class ReservationSystem{

    private:

    public:

        ReservationSystem();

        void makeReservation();

        void modifiReservation();

        void cancelReservation();

        void searchReservation();

        void exitReservation();

};