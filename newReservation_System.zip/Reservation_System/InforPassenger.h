#ifndef InforPassenger_h
#define InforPassenger_h

#include "ResData.h"
#include "Ticket.h"


using namespace std;

class InforPassenger{

    private:
            
    public:
            InforPassenger();

            void getInforPassenger();

};

#endif