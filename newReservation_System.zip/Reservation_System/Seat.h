#ifndef Seat_h
#define Seat_h
#include <vector>
#include <string>

using namespace std;

class Seat{

    private:
        int index;
        bool take;
        string namePassenger;
        
    public:
        Seat();

        Seat(int);

        int getIndex();

        bool getTake();

        void setIndex(int);

        void setTake(bool);

        void setNamePassenger(string);
        
        string getNamePassenger();
};

#endif
