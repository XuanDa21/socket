#ifndef Ticket_h
#define Ticket_h
#include <string>
#include <vector>
using namespace std;

class Ticket {

    private:
        string nameOfPassenger, departureCity, destinationCity, date, time;
        int ticketNum;
        vector<int> positionSeat;

    public:
        Ticket();

        Ticket(int);

        string getNameOfPassenger();

        string getDepartureCity(); 

        string getDestinationCity();

        string getDate();

        string getTime();

        vector<int> getPositionSeat();

        int getTicketNum();

        void setNameOfPassenger(string);

        void setDepartureCity(string); 

        void setDestinationCity(string);

        void setDate(string);

        void setTime(string);

        void setTicketNum(int);

        void setPositionSeat(vector<int>);
        
};

#endif