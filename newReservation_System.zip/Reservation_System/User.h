#ifndef User_h
#define User_h

#include "ResData.h"
#include "Ticket.h"
#include "Seat.h"
#include "Bus.h"
#include <vector>
#include <string>
#include <cstring>

using namespace std;

class User{

    private:
            
    public:
            User();

            Ticket ticket;

            void setInForPassenger();

            void printInforPassenger(Ticket ticket);

            string getNameToCancel();

            string getNameToModify();

            vector<int> getSeatPassenger(vector<Ticket>);

            vector<string> getInforToSearch();

            vector<Ticket> getInforPassenger();

};

#endif